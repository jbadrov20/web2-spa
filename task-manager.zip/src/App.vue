<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
/* Ovdje možeš dodati globalne stilove ako želiš */
</style>
