<template>
  <div>
    <h1>Stranica nije pronađena</h1>
    <p>Greška 404: Ova stranica ne postoji.</p>
    <router-link to="/">Vrati se na početnu</router-link>
  </div>
</template>
